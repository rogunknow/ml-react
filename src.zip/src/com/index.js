export { default as Navigation } from "./Navigation";
export { default as Footer } from "./Footer";
export { default as Home } from "./parts/Home";
export { default as About } from "./parts/About";
export { default as Contact } from "./Contact";